package com.example.psipsi.retorofit.Pengaduan;

public class ResponseBuatPengaduan {
    String status;
    int data;
}
