<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;

return function (App $app) {
    $container = $app->getContainer();

    // $app->get('/[{name}]', function (Request $request, Response $response, array $args) use ($container) {
    //     // Sample log message
    //     $container->get('logger')->info("Slim-Skeleton '/' route");

    //     // Render index view
    //     return $container->get('renderer')->render($response, 'index.phtml', $args);
    // });
    $app->get("/datapengaduan", function (Request $request, Response $response){
        $sql = "SELECT * FROM pengaduans  ORDER BY created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $response->withJson(["status" => "success", "pengaduan" => $result], 200);
        
    });
    $app->get("/provinsi", function (Request $request, Response $response){
        $sql = "SELECT name FROM provinces";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $response->withJson(["status" => "success","provinsi" => $result], 200);
        
    });
    $app->post("/kecamatan", function (Request $request, Response $response){
        $body = $request->getParsedBody();
        $sql = "SELECT r.name FROM districts  r inner join regencies p where p.id = r.regency_id && p.name = :kabupaten";
        $stmt = $this->db->prepare($sql);
        $data = [
            ":kabupaten" => $body["kabupaten"]   
        ];
        $stmt->execute($data);
        $result = $stmt->fetchAll();
        return $response->withJson(["status" => "success","kecamatan" => $result], 200);
        
    });
    $app->get("/kategori", function (Request $request, Response $response){
        $body = $request->getParsedBody();
        $sql = "SELECT name FROM kategoripengaduans";
        $stmt = $this->db->prepare($sql);
       
        $stmt->execute();
        $result = $stmt->fetchAll();
        return $response->withJson(["status" => "success","provinsi" => $result], 200);
        
    });
    $app->post("/kabupaten", function (Request $request, Response $response){
        $body = $request->getParsedBody();
        $sql = "SELECT r.name FROM regencies r inner join provinces p where p.id = r.province_id && p.name = :provinsi";
        $stmt = $this->db->prepare($sql);
        $data = [
            ":provinsi" => $body["provinsi"]   
        ];
        $stmt->execute($data);
        $result = $stmt->fetchAll();
        return $response->withJson(["status" => "success","kabupaten" => $result], 200);
        
    });
    $app->post("/desa", function (Request $request, Response $response){
        $body = $request->getParsedBody();
        $sql = "SELECT r.name FROM villages r inner join districts p where p.id = r.district_id && p.name = :kecamatan";
        $stmt = $this->db->prepare($sql);
        $data = [
            ":kecamatan" => $body["kecamatan"]   
        ];
        $stmt->execute($data);
        $result = $stmt->fetchAll();
        return $response->withJson(["status" => "success","kecamatan" => $result], 200);
        
    });
    $app->post("/buatpengaduan", function (Request $request, Response $response){

        $body = $request->getParsedBody();
    
        $sql = "INSERT INTO `pengaduans` (`id`, `nik`, `judul`, `kategori_pengaduan`, `provinsi`, `kabupaten`, `kecamatan`, `desa`, `lokasi_pengaduan`, `deskripsi`, `image`, `status_pengaduan`, `tanggal`, `created_at`, `updated_at`, `nama`, `diteruskan_ke`, `alasan_diteruskan`) VALUES 
        (NULL, :nik, :judul, :kategori, :provinsi, :kabupaten, :kecamatan, :desa, :lokasi, :deskripsi, NULL, 'belum diproses', now(), now(), now(), :nama, NULL, NULL);";
        $stmt = $this->db->prepare($sql);
    
        $data = [
            ":nama" => $body["nama"],
            ":nik" => $body["nik"],
            ":kategori" => $body["kategori"],
            ":provinsi" => $body["provinsi"],
            ":kabupaten" => $body["kabupaten"],
            ":kecamatan" => $body["kecamatan"],
            ":deskripsi" => $body["deskripsi"],
            ":desa" => $body["desa"],
            ":lokasi" => $body["lokasi"],
            ":judul" => $body["judul"]
        ];
    
        if($stmt->execute($data))
           return $response->withJson(["status" => "success", "data" => "1"], 200);
        
        return $response->withJson(["status" => "failed", "data" => "0"], 200);
    });
    $app->post("/finduser", function (Request $request, Response $response, $args){
        $body = $request->getParsedBody();
        $sql = "SELECT s.id, s.name,r.name as role,s.nik     FROM users s INNER join role_user u ON s.id = u.user_id JOIN roles r ON r.id = u.role_id WHERE email=:email && password=:password ";
    
        $data = [
            ":email" => $body["email"],
            ":password" => md5($body["password"])            
        ];
        $stmt = $this->db->prepare($sql);
        $stmt->execute($data);
        $result = $stmt->fetch();
        if($result == false){
            return $response->withJson(["status" => "false", "data" => $result], 200);
        }
        else{
            return $response->withJson(["status" => "success", "user" => $result], 200);
        }
        });
        $app->post("/cekemail", function (Request $request, Response $response, $args){
            $body = $request->getParsedBody();
            $sql = "SELECT email from users where email= :email";
        
            $data = [
                ":email" => $body["email"]           
            ];
            $stmt = $this->db->prepare($sql);
            $stmt->execute($data);
            $result = $stmt->fetch();
            if($result == false){
                return $response->withJson(["status" => "tidak ada"], 200);
            }
            else{
                return $response->withJson(["status" => "sudah ada"], 200);
            }
            });

        $app->post("/createuser", function (Request $request, Response $response, $args){
        $body = $request->getParsedBody();
        $sql = "INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `nik`, `alamat`, `nomor_telepon`, `jenis_kelamin`) VALUES (NULL, :nama, :email, NULL, :password, NULL, now(),now(), :nik, :alamat, :nomor, '-')";
        $stmt = $this->db->prepare($sql);
        $data = [
            ":nama" => $body["nama"],
            ":email" => $body["email"],
            ":password" => md5($body["password"]),
            ":nik" => $body["nik"],
            ":alamat" => $body["alamat"],
            ":nomor" => $body["nomor"]
            
                        
        ];
        $sql4 = "SELECT email from users where email= :email";
        
        $data4 = [
            ":email" => $body["email"]           
        ];
        $stmt4 = $this->db->prepare($sql4);
        $stmt4->execute($data4);
        $result4 = $stmt4->fetch();
        if($result4 != false){
            return $response->withJson(["status" => "sudah ada"], 200);

        }

        if($stmt->execute($data)){
            $sql2 = "INSERT INTO `role_user` (`id`, `role_id`, `user_id`, `created_at`, `updated_at`) VALUES (NULL, '3', :id, now(), now())" ;
            $sql3 = "SELECT * FROM users where email = :email";
            $stmt2 = $this->db->prepare($sql2);
            $data3 = [
                ":email" => $body['email']
                            
            ];
            $stmt3 = $this->db->prepare($sql3);
            $stmt3->execute($data3);
            $result3 = $stmt3->fetch();
            $data2 = [
                ":id" => $result3['id']
                            
            ];
            $stmt2->execute($data2);

            return $response->withJson(["status" => "success", "data" => "1"], 200);
        }
        else{
        return $response->withJson(["status" => "failed", "data" => "0"], 200);
        }
        });
        
};
